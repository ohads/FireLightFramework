//
//  FireLightFramework.h
//  FireLightFramework
//
//  Created by Ohad Shulz on 20/03/2020.
//  Copyright © 2020 firelight. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for FireLightFramework.
FOUNDATION_EXPORT double FireLightFrameworkVersionNumber;

//! Project version string for FireLightFramework.
FOUNDATION_EXPORT const unsigned char FireLightFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FireLightFramework/PublicHeader.h>


